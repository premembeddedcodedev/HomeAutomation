#define CATCH_CONFIG_MAIN

#include "catch2/catch.hpp"

#include <Arduino.h>

#include "catch_utils.hpp"

#include "painlessmesh/ntp.hpp"

using namespace painlessmesh;

logger::LogClass Log;
